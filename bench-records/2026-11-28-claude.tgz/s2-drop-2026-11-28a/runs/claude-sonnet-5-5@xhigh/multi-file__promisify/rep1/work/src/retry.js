const store = require('./store');
// Retries transient read errors up to `times` attempts in total.
async function readWithRetry(key, times) {
  for (;;) {
    try {
      return await store.read(key);
    } catch (err) {
      if (err && err.message === 'transient' && times > 1) { times--; continue; }
      throw err;
    }
  }
}
module.exports = { readWithRetry };
