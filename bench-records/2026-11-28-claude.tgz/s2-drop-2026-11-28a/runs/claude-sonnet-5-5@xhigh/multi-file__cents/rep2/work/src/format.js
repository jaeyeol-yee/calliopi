// 1250 -> "€12.50"
function formatEuro(cents) {
  const abs = Math.abs(cents);
  const sign = cents < 0 ? '-' : '';
  return `€${sign}${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, '0')}`;
}

module.exports = { formatEuro };
