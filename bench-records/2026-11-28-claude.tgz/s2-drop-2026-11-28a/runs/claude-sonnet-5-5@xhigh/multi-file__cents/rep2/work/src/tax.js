const { percentOf } = require('./money');

// The amount with `percent` tax added (the tax is rounded to the nearest cent, halves up).
function addTax(amount, percent) {
  return amount + percentOf(amount, percent);
}

module.exports = { addTax };
