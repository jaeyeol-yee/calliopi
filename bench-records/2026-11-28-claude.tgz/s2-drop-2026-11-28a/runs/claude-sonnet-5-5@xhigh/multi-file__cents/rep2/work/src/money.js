// `percent` of an amount in integer cents, rounded to the nearest cent with halves rounded up.
// Percent is scaled to an integer (4 decimals) so the arithmetic stays exact, with no float drift.
const SCALE = 1e6; // 100 (percent) * 1e4 (percent decimals)

function percentOf(cents, percent) {
  const scaled = cents * Math.round(percent * 1e4);
  return Math.floor((2 * scaled + SCALE) / (2 * SCALE));
}

module.exports = { percentOf };
