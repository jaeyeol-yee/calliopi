// `percent` of an amount in integer cents, rounded to the nearest cent with halves rounded up.
// For integer cents and percent the arithmetic stays in exact integers (no float drift).
function percentOf(cents, percent) {
  return Math.floor((cents * percent + 50) / 100);
}

module.exports = { percentOf };
