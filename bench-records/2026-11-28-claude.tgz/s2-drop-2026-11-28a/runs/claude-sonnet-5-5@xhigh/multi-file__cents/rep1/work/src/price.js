const { percentOf } = require('./round');

// Amounts are integer cents.
function lineTotal(cents, qty) {
  return cents * qty;
}

// The amount after `percent` off (the discount is rounded to the nearest cent, halves up).
function applyDiscount(amount, percent) {
  return amount - percentOf(amount, percent);
}

module.exports = { lineTotal, applyDiscount };
