// Price from cents. locale: 'en' (default, €12.50) or 'de' (12,50 €).
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale !== 'de') return `€${fixed}`;
  const negative = fixed.startsWith('-');
  const [whole, fraction] = (negative ? fixed.slice(1) : fixed).split('.');
  const grouped = whole.replace(/\B(?=(\d{3})+$)/g, '.');
  return `${negative ? '-' : ''}${grouped},${fraction} €`;
}
module.exports = { formatPrice };
