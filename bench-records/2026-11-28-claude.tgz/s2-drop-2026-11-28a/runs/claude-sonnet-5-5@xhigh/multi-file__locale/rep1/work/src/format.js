// Euros from cents. locale: 'en' (default) -> "€12.50", 'de' -> "1.234,50 €".
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale !== 'de') return `€${fixed}`;
  const [int, frac] = fixed.split('.');
  const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${grouped},${frac} €`;
}
module.exports = { formatPrice };
