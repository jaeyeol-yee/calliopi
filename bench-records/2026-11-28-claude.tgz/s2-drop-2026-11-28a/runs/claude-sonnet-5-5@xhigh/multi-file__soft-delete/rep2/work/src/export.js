const notes = require('./notes');

// A header line, then one line per note in id order, archived notes included.
function toCsv() {
  const rows = notes.list({ includeArchived: true })
    .map(note => `${note.id},${note.title},${note.tag},${note.archived ? 'yes' : 'no'}`);
  return ['id,title,tag,archived', ...rows].join('\n');
}

module.exports = { toCsv };
