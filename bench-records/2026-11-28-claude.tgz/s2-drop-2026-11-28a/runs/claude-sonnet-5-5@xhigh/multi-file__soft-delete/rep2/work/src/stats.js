const notes = require('./notes');

// { total, byTag: { tag: count } }, archived notes not counted.
function summary() {
  const active = notes.list();
  const byTag = {};
  for (const note of active) byTag[note.tag] = (byTag[note.tag] ?? 0) + 1;
  return { total: active.length, byTag };
}

module.exports = { summary };
