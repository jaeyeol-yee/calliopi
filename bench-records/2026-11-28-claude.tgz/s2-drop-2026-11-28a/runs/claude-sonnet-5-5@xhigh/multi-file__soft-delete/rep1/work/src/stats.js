const store = require('./store');

// { total, byTag: { tag: count } }, archived notes not counted.
function summary() {
  const byTag = {};
  const active = store.all().filter(note => !note.archived);
  for (const note of active) byTag[note.tag] = (byTag[note.tag] ?? 0) + 1;
  return { total: active.length, byTag };
}

module.exports = { summary };
