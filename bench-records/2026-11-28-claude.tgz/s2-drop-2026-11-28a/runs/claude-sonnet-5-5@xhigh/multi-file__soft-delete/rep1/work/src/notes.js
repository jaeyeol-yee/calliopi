const store = require('./store');

function create(title, tag) {
  return store.insert({ title, tag, archived: false });
}

// Archived notes are still returned.
function get(id) {
  return store.find(id);
}

// Archived notes are left out unless includeArchived is set.
function list({ includeArchived = false } = {}) {
  return store.all().filter(note => includeArchived || !note.archived);
}

function count() {
  return list().length;
}

// Archives the note. True when there was an active one; false when unknown or already archived.
function remove(id) {
  const note = store.find(id);
  if (!note || note.archived) return false;
  note.archived = true;
  return true;
}

// Un-archives the note. True when it was archived; false when unknown or not archived.
function restore(id) {
  const note = store.find(id);
  if (!note || !note.archived) return false;
  note.archived = false;
  return true;
}

module.exports = { create, get, list, count, remove, restore };
