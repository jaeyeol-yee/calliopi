const { startServer } = require('./server');
// node src/cli.js --debug
function main(argv) {
  return startServer({ debug: argv.includes('--debug'), port: 8080 });
}
module.exports = { main };
