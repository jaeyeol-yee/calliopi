const { formatPrice } = require('./format');
function summary(items, locale = 'en') {
  const cents = items.reduce((a, i) => a + i.cents * i.qty, 0);
  return `${items.length} items, ${formatPrice(cents, locale)}`;
}
module.exports = { summary };
