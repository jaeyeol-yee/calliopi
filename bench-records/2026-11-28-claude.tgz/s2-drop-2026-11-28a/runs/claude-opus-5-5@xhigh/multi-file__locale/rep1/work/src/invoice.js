const { formatPrice } = require('./format');
function invoiceLine(item, locale = 'en') {
  return `${item.name} × ${item.qty}: ${formatPrice(item.cents * item.qty, locale)}`;
}
module.exports = { invoiceLine };
