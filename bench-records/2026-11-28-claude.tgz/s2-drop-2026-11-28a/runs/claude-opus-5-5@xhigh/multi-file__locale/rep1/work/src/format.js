// Euros from cents.
// locale: 'en' (default) -> "€2011.50", 'de' -> "2.011,50 €".
function formatPrice(cents, locale = 'en') {
  if (locale === 'en') {
    return `€${(cents / 100).toFixed(2)}`;
  }
  if (locale === 'de') {
    const fixed = (cents / 100).toFixed(2);
    const negative = fixed.startsWith('-');
    const [int, dec] = (negative ? fixed.slice(1) : fixed).split('.');
    const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return `${negative ? '-' : ''}${grouped},${dec} €`;
  }
  throw new RangeError(`Unsupported locale: ${locale}`);
}
module.exports = { formatPrice };
