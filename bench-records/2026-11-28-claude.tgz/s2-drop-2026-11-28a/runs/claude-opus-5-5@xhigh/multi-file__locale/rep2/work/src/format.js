// Euros from cents.
// locale 'en' (default): €2011.50 — sign first, decimal point, no grouping.
// locale 'de': 2.011,50 € — sign last, decimal comma, dot thousands grouping.
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale === 'en') return `€${fixed}`;
  if (locale === 'de') {
    const negative = fixed.startsWith('-');
    const [whole, frac] = (negative ? fixed.slice(1) : fixed).split('.');
    const grouped = whole.replace(/\B(?=(\d{3})+$)/g, '.');
    return `${negative ? '-' : ''}${grouped},${frac} €`;
  }
  throw new RangeError(`Unsupported locale: ${locale}`);
}
module.exports = { formatPrice };
