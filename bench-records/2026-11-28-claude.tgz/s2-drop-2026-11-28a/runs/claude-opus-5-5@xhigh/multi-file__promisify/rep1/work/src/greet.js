const { readWithRetry } = require('./retry');
async function greeting(name) {
  const word = await readWithRetry('greeting', 3);
  return `${word}, ${name}`;
}
module.exports = { greeting };
