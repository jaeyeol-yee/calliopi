const { readWithRetry } = require('./retry');
async function nextCount() {
  const raw = await readWithRetry('count', 2);
  return Number(raw) + 1;
}
module.exports = { nextCount };
