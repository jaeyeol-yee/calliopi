// 1250 (cents) -> "€12.50"
function formatEuro(cents) {
  return `€${(cents / 100).toFixed(2)}`;
}

module.exports = { formatEuro };
