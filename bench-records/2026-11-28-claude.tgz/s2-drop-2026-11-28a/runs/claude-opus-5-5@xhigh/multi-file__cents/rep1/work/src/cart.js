const { lineTotal, applyDiscount } = require('./price');
const { addTax } = require('./tax');

// items: [{ name, cents, qty }]; returns integer cents.
// The discount applies to the subtotal, then tax to what is left.
function cartTotal(items, { discountPercent = 0, taxPercent = 0 } = {}) {
  const subtotal = items.reduce((sum, item) => sum + lineTotal(item.cents, item.qty), 0);
  return addTax(applyDiscount(subtotal, discountPercent), taxPercent);
}

module.exports = { cartTotal };
