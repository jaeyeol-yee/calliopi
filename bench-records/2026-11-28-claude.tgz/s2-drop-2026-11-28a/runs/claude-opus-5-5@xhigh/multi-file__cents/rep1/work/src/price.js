// Amounts are integer cents.
function lineTotal(cents, qty) {
  return cents * qty;
}

// `percent` of `cents`, rounded to the nearest cent with halves rounded up.
// Worked out in exact integer arithmetic, so fractional rates such as 8.25 round correctly too.
function percentOf(cents, percent) {
  const [whole, fraction = ''] = String(percent).split('.');
  const rate = BigInt(whole + fraction);             // percent × 10^digits
  const per = 100n * 10n ** BigInt(fraction.length); // ...out of this many
  const twice = 2n * BigInt(cents) * rate + per;     // 2 × (exact share + ½ cent), in units of 1/per
  let rounded = twice / (2n * per);                  // BigInt division truncates toward zero...
  if (twice < 0n && twice % (2n * per) !== 0n) rounded -= 1n; // ...so floor it for negatives
  return Number(rounded);
}

// The amount after `percent` off.
function applyDiscount(cents, percent) {
  return cents - percentOf(cents, percent);
}

module.exports = { lineTotal, applyDiscount, percentOf };
