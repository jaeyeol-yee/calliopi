const { percentOf } = require('./price');

// The amount with `percent` tax added.
function addTax(cents, percent) {
  return cents + percentOf(cents, percent);
}

module.exports = { addTax };
