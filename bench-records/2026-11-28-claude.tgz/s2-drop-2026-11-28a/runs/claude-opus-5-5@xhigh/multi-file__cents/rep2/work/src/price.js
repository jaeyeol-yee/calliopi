// Amounts are integer cents.
function lineTotal(cents, qty) {
  return cents * qty;
}

// `percent` of `cents`, rounded to the nearest cent with halves rounded up.
// The percent is read as the decimal it is written as (8.1 -> 81 / 1000), so that
// 8.1% of 500 cents is exactly 40.5 and rounds up to 41 rather than drifting below the half.
function percentOf(cents, percent) {
  const decimals = (String(percent).split('.')[1] || '').length;
  const scale = 10 ** decimals;
  const numerator = Math.round(percent * scale);
  const denominator = 100 * scale;
  return Math.floor((cents * numerator + denominator / 2) / denominator);
}

// The amount after `percent` off.
function applyDiscount(cents, percent) {
  return cents - percentOf(cents, percent);
}

module.exports = { lineTotal, applyDiscount, percentOf };
