const { percentOf } = require('./price');

// The amount in cents with `percent` tax added.
function addTax(cents, percent) {
  return cents + percentOf(cents, percent);
}

module.exports = { addTax };
