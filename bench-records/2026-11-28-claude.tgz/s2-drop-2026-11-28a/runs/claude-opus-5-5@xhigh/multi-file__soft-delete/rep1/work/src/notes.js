const store = require('./store');

function create(title, tag) {
  return store.insert({ title, tag, archived: false });
}

// Archived notes are returned too.
function get(id) {
  return store.find(id);
}

// Notes that are not archived; all of them with { includeArchived: true }.
function list({ includeArchived = false } = {}) {
  const all = store.all();
  return includeArchived ? all : all.filter(note => !note.archived);
}

// Counts notes that are not archived.
function count() {
  return list().length;
}

// Archives the note; it is kept. True when it was there and not archived yet.
function remove(id) {
  const note = store.find(id);
  if (!note || note.archived) return false;
  store.update(id, { archived: true });
  return true;
}

// Un-archives the note. True when it was there and archived.
function restore(id) {
  const note = store.find(id);
  if (!note || !note.archived) return false;
  store.update(id, { archived: false });
  return true;
}

module.exports = { create, get, list, count, remove, restore };
