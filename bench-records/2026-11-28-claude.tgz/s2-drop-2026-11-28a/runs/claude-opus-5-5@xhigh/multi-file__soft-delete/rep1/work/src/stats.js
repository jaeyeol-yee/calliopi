const notes = require('./notes');

// { total, byTag: { tag: count } }, over notes that are not archived.
function summary() {
  const active = notes.list();
  const byTag = {};
  for (const note of active) byTag[note.tag] = (byTag[note.tag] ?? 0) + 1;
  return { total: active.length, byTag };
}

module.exports = { summary };
