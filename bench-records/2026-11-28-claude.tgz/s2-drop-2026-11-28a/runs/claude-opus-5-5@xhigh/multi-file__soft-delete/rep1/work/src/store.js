// Notes in memory, by id.
const notes = new Map();
let nextId = 1;

function insert(fields) {
  const note = { id: nextId++, ...fields };
  notes.set(note.id, note);
  return note;
}

function find(id) {
  return notes.get(id);
}

function all() {
  return [...notes.values()];
}

// Merges fields into the note. Returns the note, or undefined when there is none.
function update(id, fields) {
  const note = notes.get(id);
  return note && Object.assign(note, fields);
}

function erase(id) {
  return notes.delete(id);
}

function reset() {
  notes.clear();
  nextId = 1;
}

module.exports = { insert, find, all, update, erase, reset };
