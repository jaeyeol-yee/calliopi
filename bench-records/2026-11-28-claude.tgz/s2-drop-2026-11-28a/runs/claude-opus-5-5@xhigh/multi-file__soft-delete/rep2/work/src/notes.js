const store = require('./store');

function create(title, tag) {
  return store.insert({ title, tag, archived: false });
}

// Archived notes are still found by id.
function get(id) {
  return store.find(id);
}

// Notes that are not archived; all notes with { includeArchived: true }.
function list({ includeArchived = false } = {}) {
  return includeArchived ? store.all() : store.all().filter(note => !note.archived);
}

// Counts notes that are not archived.
function count() {
  return list().length;
}

// Archives the note (soft delete). True when there was one that was not archived yet.
function remove(id) {
  const note = store.find(id);
  if (!note || note.archived) return false;
  note.archived = true;
  return true;
}

// Un-archives the note. True when there was one that was archived.
function restore(id) {
  const note = store.find(id);
  if (!note || !note.archived) return false;
  note.archived = false;
  return true;
}

module.exports = { create, get, list, count, remove, restore };
