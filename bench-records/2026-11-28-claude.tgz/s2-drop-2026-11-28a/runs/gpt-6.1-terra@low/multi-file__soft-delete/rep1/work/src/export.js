const store = require('./store');

// A header line, then one line per note in id order.
function toCsv() {
  return ['id,title,tag,archived', ...store.all().map(note => `${note.id},${note.title},${note.tag},${note.archived ? 'yes' : 'no'}`)].join('\n');
}

module.exports = { toCsv };
