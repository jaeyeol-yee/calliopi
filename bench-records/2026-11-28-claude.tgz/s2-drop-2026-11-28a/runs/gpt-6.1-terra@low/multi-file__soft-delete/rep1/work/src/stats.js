const notes = require('./notes');

// { total, byTag: { tag: count } }
function summary() {
  const byTag = {};
  const active = notes.list();
  for (const note of active) byTag[note.tag] = (byTag[note.tag] ?? 0) + 1;
  return { total: active.length, byTag };
}

module.exports = { summary };
