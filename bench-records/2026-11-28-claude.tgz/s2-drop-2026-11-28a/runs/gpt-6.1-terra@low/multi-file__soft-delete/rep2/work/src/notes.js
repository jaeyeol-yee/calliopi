const store = require('./store');

function create(title, tag) {
  return store.insert({ title, tag });
}

function get(id) {
  return store.find(id);
}

function list({ includeArchived = false } = {}) {
  return store.all().filter(note => includeArchived || !note.archived);
}

function count() {
  return list().length;
}

function remove(id) {
  const note = store.find(id);
  if (!note || note.archived) return false;
  note.archived = true;
  return true;
}

function restore(id) {
  const note = store.find(id);
  if (!note || !note.archived) return false;
  note.archived = false;
  return true;
}

module.exports = { create, get, list, count, remove, restore };
