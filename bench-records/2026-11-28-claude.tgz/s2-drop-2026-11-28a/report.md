# Benchmark: s2-drop

- Pi 1.7.0 · harness ac21e38113a3 · tasks multi-file/cents@v3, multi-file/locale@v4, multi-file/promisify@v4, multi-file/rename-option@v4, multi-file/soft-delete@v3, review/bounds@v3, review/duration@v4, review/pagination@v4, review/spot-bug@v3, review/token-bucket@v3, search/direct-callers@v3, search/find-default@v3, search/purge-routes@v2, search/trace-port@v3, search/unused-flags@v2, small-fix/event-order@v3, small-fix/lru@v4, small-fix/off-by-one@v4, small-fix/task-queue@v3, small-fix/thousands@v4
- 425 runs, $11.51 total
- 6 runs ended on a provider error and are left out: The ChatGPT user has reached their Subscription Sharing usage limit. Ask the user to try again after their usage limit r

## By arm and task class

Strict pass: every dimension the task has passed (outcome, diagnosis, citation, coverage, scope, hidden tests). Extra findings (review: cited lines that are no bug) are counted beside it and fail nothing; so are the answer's words (median) and how they split: needed (blocks with something the task requires), allowed (justification, verification, what is no bug), surplus (neither).
Cost includes subagents. Cost, turns and tokens (the run's own) are medians per run; ranges are min–max. tok/s: output tokens per second of responses of 50 tokens or more, end to end (it includes the wait for the first token), median per run then over runs; model time: the share of a run's wall time spent waiting on the model. Both are slower when runs went at once.

| class | arm | harness | strict pass | worst–best rep | by dimension | extra findings (runs) | answer words | needed / allowed / surplus | $/run | $ range | turns | tokens | tokens range | cache hit | tok/s | model time | tool errors | parallel | out of scope | timeouts | subagents (stopped) | provider errors |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| multi-file | gpt-6.1-terra@high | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 31 | 65% / 35% / 0% | $0.0104 | $0.0044–$0.0270 | 6.0 | 22746 | 16406–40273 | 80% | 25 | 96% | 0 | 28% | 0 | 0 | 2 (0) | 0 |
| multi-file | gpt-6.1-terra@low | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 31 | 68% / 32% / 0% | $0.0106 | $0.0071–$0.0247 | 7.0 | 26578 | 21836–39830 | 75% | 33 | 97% | 1 | 23% | 0 | 0 | 1 (0) | 0 |
| multi-file | gpt-6.1-terra@medium | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 30 | 70% / 30% / 0% | $0.0117 | $0.0058–$0.0127 | 8.0 | 30252 | 24199–43319 | 81% | 31 | 97% | 0 | 12% | 0 | 0 | 0 (0) | 0 |
| multi-file | gpt-6.1-terra@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 31 | 66% / 34% / 0% | $0.0145 | $0.0064–$0.0392 | 6.5 | 26935 | 18379–50252 | 62% | 27 | 97% | 1 | 33% | 0 | 0 | 1 (0) | 0 |
| multi-file | claude-sonnet-5-5@medium | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 76 | 64% / 19% / 17% | $0.0205 | $0.0128–$0.0281 | 4.0 | 25837 | 20742–44156 | 88% | 84 | 92% | 2 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file | claude-sonnet-5-5@low | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 78 | 48% / 23% / 29% | $0.0231 | $0.0131–$0.0274 | 4.5 | 32195 | 24401–43668 | 89% | 73 | 93% | 2 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file | claude-sonnet-5-5@high | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 97 | 58% / 35% / 8% | $0.0256 | $0.0205–$0.0281 | 5.0 | 36571 | 20987–55383 | 89% | 93 | 93% | 2 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file | claude-sonnet-5-5@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 109 | 68% / 23% / 9% | $0.0311 | $0.0265–$0.0342 | 5.0 | 37572 | 29628–53767 | 87% | 96 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file | claude-opus-5-5@low | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 104 | 65% / 27% / 9% | $0.0457 | $0.0378–$0.0552 | 4.5 | 33809 | 20283–47203 | 88% | 73 | 94% | 2 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file | claude-opus-5-5@medium | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 117 | 57% / 28% / 15% | $0.0518 | $0.0381–$0.0583 | 5.0 | 35047 | 28968–38360 | 87% | 70 | 94% | 6 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file | claude-opus-5-5@high | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 118 | 77% / 12% / 11% | $0.0546 | $0.0428–$0.0614 | 5.0 | 34806 | 30208–43134 | 87% | 73 | 94% | 4 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file | claude-opus-5-5@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 127 | 74% / 17% / 8% | $0.0731 | $0.0614–$0.0911 | 6.0 | 47588 | 44979–58997 | 88% | 76 | 95% | 1 | 11% | 0 | 0 | 0 (0) | 0 |
| multi-file-hard | claude-sonnet-5-5@medium | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 167 | 83% / 2% / 16% | $0.0296 | $0.0266–$0.0311 | 5.0 | 38027 | 22453–45633 | 87% | 86 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file-hard | claude-sonnet-5-5@low | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 140 | 87% / 5% / 9% | $0.0296 | $0.0272–$0.0319 | 6.0 | 45449 | 30281–47593 | 89% | 89 | 93% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file-hard | gpt-6.1-terra@medium | on | 3/3 | 100%–100% | outcome 3/3 · coverage 3/3 · scope 3/3 · hidden 3/3 | – | 36 | 88% / 12% / 0% | $0.0334 | $0.0154–$0.0433 | 9.0 | 45179 | 34822–74671 | 79% | 29 | 61% | 1 | 16% | 0 | 0 | 2 (0) | 1 |
| multi-file-hard | claude-sonnet-5-5@high | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 159 | 89% / 7% / 4% | $0.0335 | $0.0287–$0.0375 | 5.0 | 39517 | 29353–41027 | 86% | 95 | 95% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file-hard | gpt-6.1-terra@low | on | 3/3 | 100%–100% | outcome 3/3 · coverage 3/3 · scope 3/3 · hidden 3/3 | – | 41 | 75% / 25% / 0% | $0.0358 | $0.0158–$0.0396 | 9.0 | 44976 | 34490–53953 | 72% | 30 | 56% | 0 | 25% | 0 | 0 | 2 (0) | 1 |
| multi-file-hard | gpt-6.1-terra@high | on | 3/3 | 100%–100% | outcome 3/3 · coverage 3/3 · scope 3/3 · hidden 3/3 | – | 44 | 69% / 31% / 0% | $0.0440 | $0.0327–$0.0472 | 10.0 | 51018 | 40943–73517 | 72% | 33 | 56% | 0 | 26% | 0 | 0 | 3 (0) | 1 |
| multi-file-hard | claude-sonnet-5-5@xhigh | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 190 | 87% / 6% / 8% | $0.0566 | $0.0484–$0.0617 | 5.5 | 51354 | 34223–68985 | 83% | 93 | 96% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file-hard | gpt-6.1-terra@xhigh | on | 3/3 | 100%–100% | outcome 3/3 · coverage 3/3 · scope 3/3 · hidden 3/3 | – | 50 | 59% / 41% / 0% | $0.0621 | $0.0434–$0.0810 | 11.0 | 61565 | 49672–99569 | 75% | 27 | 51% | 0 | 34% | 0 | 0 | 5 (0) | 1 |
| multi-file-hard | claude-opus-5-5@low | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 158 | 84% / 3% / 13% | $0.0650 | $0.0553–$0.0709 | 4.5 | 36512 | 31233–41469 | 85% | 80 | 95% | 2 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file-hard | claude-opus-5-5@medium | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 207 | 85% / 6% / 9% | $0.0799 | $0.0607–$0.0903 | 4.5 | 38217 | 23012–43806 | 82% | 88 | 96% | 1 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file-hard | claude-opus-5-5@high | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 228 | 75% / 12% / 13% | $0.0876 | $0.0759–$0.0898 | 4.5 | 39176 | 33997–44056 | 83% | 91 | 97% | 3 | 0% | 0 | 0 | 0 (0) | 0 |
| multi-file-hard | claude-opus-5-5@xhigh | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 240 | 82% / 7% / 11% | $0.19 | $0.15–$0.23 | 7.0 | 77533 | 59036–105324 | 86% | 95 | 97% | 0 | 14% | 0 | 0 | 0 (0) | 0 |
| review | gpt-6.1-terra@xhigh | on | 3/3 | 100%–100% | outcome 3/3 · diagnosis 3/3 · citation 3/3 · scope 3/3 | 1 (1) | 45 | 84% / 0% / 16% | $0.0017 | $0.0014–$0.0061 | 2.0 | 6060 | 5945–14731 | 90% | 18 | 97% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | gpt-6.1-terra@medium | on | 3/3 | 100%–100% | outcome 3/3 · diagnosis 3/3 · citation 3/3 · scope 3/3 | 0 (0) | 28 | 100% / 0% / 0% | $0.0022 | $0.0012–$0.0036 | 2.0 | 5944 | 5882–6253 | 76% | 31 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | gpt-6.1-terra@high | on | 3/3 | 100%–100% | outcome 3/3 · diagnosis 3/3 · citation 3/3 · scope 3/3 | 0 (0) | 35 | 100% / 0% / 0% | $0.0036 | $0.0013–$0.0038 | 2.0 | 5974 | 5876–10113 | 77% | 19 | 95% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | gpt-6.1-terra@low | on | 3/3 | 100%–100% | outcome 3/3 · diagnosis 3/3 · citation 3/3 · scope 3/3 | 0 (0) | 35 | 100% / 0% / 0% | $0.0062 | $0.0045–$0.0063 | 2.0 | 5946 | 5878–6193 | 15% | 24 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 1 |
| review | claude-sonnet-5-5@low | on | 4/6 | 67%–67% | outcome 6/6 · diagnosis 6/6 · citation 4/6 · scope 6/6 | 2 (2) | 93 | 55% / 41% / 4% | $0.0091 | $0.0089–$0.0116 | 2.0 | 11874 | 11804–12249 | 81% | 84 | 89% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | claude-sonnet-5-5@medium | on | 3/6 | 33%–67% | outcome 6/6 · diagnosis 6/6 · citation 3/6 · scope 6/6 | 3 (3) | 96 | 58% / 37% / 5% | $0.0094 | $0.0089–$0.0104 | 2.0 | 11907 | 11800–12132 | 81% | 71 | 91% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | claude-sonnet-5-5@high | on | 3/6 | 33%–67% | outcome 6/6 · diagnosis 6/6 · citation 3/6 · scope 6/6 | 3 (3) | 122 | 66% / 31% / 4% | $0.0111 | $0.0103–$0.0166 | 2.0 | 12078 | 11937–12750 | 81% | 87 | 92% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | claude-sonnet-5-5@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · diagnosis 6/6 · citation 6/6 · scope 6/6 | 0 (0) | 130 | 58% / 35% / 7% | $0.0126 | $0.0107–$0.0230 | 2.0 | 12227 | 11980–20210 | 82% | 95 | 93% | 1 | 0% | 0 | 0 | 0 (0) | 0 |
| review | claude-opus-5-5@low | on | 6/6 | 100%–100% | outcome 6/6 · diagnosis 6/6 · citation 6/6 · scope 6/6 | 0 (0) | 113 | 71% / 29% / 0% | $0.0201 | $0.0180–$0.0285 | 2.0 | 11952 | 11812–12521 | 81% | 69 | 93% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | claude-opus-5-5@medium | on | 6/6 | 100%–100% | outcome 6/6 · diagnosis 6/6 · citation 6/6 · scope 6/6 | 0 (0) | 171 | 59% / 37% / 3% | $0.0247 | $0.0216–$0.0337 | 2.0 | 12206 | 11990–12780 | 81% | 76 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | claude-opus-5-5@high | on | 6/6 | 100%–100% | outcome 6/6 · diagnosis 6/6 · citation 6/6 · scope 6/6 | 0 (0) | 167 | 60% / 37% / 3% | $0.0254 | $0.0219–$0.0342 | 2.0 | 12238 | 12007–12797 | 81% | 72 | 95% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review | claude-opus-5-5@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · diagnosis 6/6 · citation 6/6 · scope 6/6 | 0 (0) | 186 | 54% / 42% / 4% | $0.0266 | $0.0213–$0.0578 | 2.0 | 12298 | 11978–20997 | 81% | 87 | 95% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | gpt-6.1-terra@high | on | 3/3 | 100%–100% | outcome 3/3 · diagnosis 1/1 · citation 3/3 · scope 3/3 | 1 (1) | 2 | 81% / 19% / 0% | $0.0014 | $0.0013–$0.0064 | 2.0 | 6165 | 6164–10892 | 74% | 27 | 97% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | gpt-6.1-terra@medium | on | 3/3 | 100%–100% | outcome 3/3 · diagnosis 1/1 · citation 3/3 · scope 3/3 | 1 (1) | 2 | 77% / 0% / 23% | $0.0036 | $0.0013–$0.0038 | 2.0 | 6142 | 6127–10842 | 74% | 24 | 95% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | gpt-6.1-terra@low | on | 3/3 | 100%–100% | outcome 3/3 · diagnosis 1/1 · citation 3/3 · scope 3/3 | 1 (1) | 15 | 68% / 12% / 20% | $0.0040 | $0.0011–$0.0063 | 2.0 | 6134 | 6113–10753 | 59% | 37 | 93% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | gpt-6.1-terra@xhigh | on | 2/2 | 100%–100% | outcome 2/2 · diagnosis 1/1 · citation 2/2 · scope 2/2 | 1 (1) | 62 | 72% / 9% / 19% | $0.0068 | $0.0031–$0.0104 | 3.0 | 11083 | 9890–12276 | 69% | 25 | 98% | 0 | 17% | 0 | 0 | 0 (0) | 1 |
| review-hard | claude-sonnet-5-5@low | on | 4/4 | 100%–100% | outcome 4/4 · diagnosis 2/2 · citation 4/4 · scope 4/4 | 0 (0) | 97 | 44% / 46% / 10% | $0.0112 | $0.0105–$0.0118 | 2.0 | 12532 | 12319–12827 | 78% | 77 | 90% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | claude-sonnet-5-5@medium | on | 4/4 | 100%–100% | outcome 4/4 · diagnosis 2/2 · citation 4/4 · scope 4/4 | 0 (0) | 112 | 54% / 45% / 1% | $0.0114 | $0.0103–$0.0183 | 2.0 | 12524 | 12276–13355 | 78% | 87 | 91% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | claude-sonnet-5-5@high | on | 3/4 | 50%–100% | outcome 4/4 · diagnosis 2/2 · citation 3/4 · scope 4/4 | 1 (1) | 132 | 57% / 26% / 17% | $0.0148 | $0.0108–$0.0211 | 2.0 | 12863 | 12321–20752 | 80% | 96 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | claude-sonnet-5-5@xhigh | on | 4/4 | 100%–100% | outcome 4/4 · diagnosis 2/2 · citation 4/4 · scope 4/4 | 0 (0) | 153 | 55% / 29% / 16% | $0.0174 | $0.0118–$0.0242 | 2.5 | 16781 | 12418–21173 | 80% | 87 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | claude-opus-5-5@low | on | 4/4 | 100%–100% | outcome 4/4 · diagnosis 2/2 · citation 4/4 · scope 4/4 | 1 (1) | 136 | 43% / 27% / 29% | $0.0254 | $0.0215–$0.0320 | 2.0 | 12728 | 12352–13244 | 77% | 73 | 93% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | claude-opus-5-5@medium | on | 4/4 | 100%–100% | outcome 4/4 · diagnosis 2/2 · citation 4/4 · scope 4/4 | 0 (0) | 158 | 51% / 28% / 21% | $0.0271 | $0.0235–$0.0425 | 2.0 | 12799 | 12415–13655 | 78% | 79 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | claude-opus-5-5@high | on | 4/4 | 100%–100% | outcome 4/4 · diagnosis 2/2 · citation 4/4 · scope 4/4 | 0 (0) | 180 | 45% / 34% / 21% | $0.0346 | $0.0247–$0.0442 | 2.0 | 13153 | 12478–13735 | 78% | 74 | 96% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| review-hard | claude-opus-5-5@xhigh | on | 4/4 | 100%–100% | outcome 4/4 · diagnosis 2/2 · citation 4/4 · scope 4/4 | 0 (0) | 228 | 51% / 37% / 12% | $0.0454 | $0.0406–$0.0597 | 3.0 | 21118 | 13719–27167 | 82% | 85 | 97% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search | gpt-6.1-terra@medium | on | 3/3 | 100%–100% | outcome 3/3 · coverage 2/2 · scope 3/3 | – | 16 | 65% / 35% / 0% | $0.0030 | $0.0021–$0.0060 | 4.0 | 13283 | 9235–13342 | 81% | 24 | 96% | 0 | 27% | 0 | 0 | 0 (0) | 0 |
| search | gpt-6.1-terra@low | on | 3/3 | 100%–100% | outcome 3/3 · coverage 2/2 · scope 3/3 | – | 12 | 74% / 26% / 0% | $0.0030 | $0.0016–$0.0034 | 4.0 | 13283 | 9097–13359 | 90% | 24 | 96% | 0 | 18% | 0 | 0 | 0 (0) | 0 |
| search | gpt-6.1-terra@high | on | 3/3 | 100%–100% | outcome 3/3 · coverage 2/2 · scope 3/3 | – | 14 | 71% / 29% / 0% | $0.0035 | $0.0018–$0.0058 | 4.0 | 13292 | 9090–13507 | 81% | 25 | 96% | 0 | 18% | 0 | 0 | 0 (0) | 0 |
| search | gpt-6.1-terra@xhigh | on | 3/3 | 100%–100% | outcome 3/3 · coverage 2/2 · scope 3/3 | – | 21 | 54% / 46% / 0% | $0.0037 | $0.0020–$0.0037 | 4.0 | 13693 | 9258–13924 | 88% | 30 | 96% | 0 | 27% | 0 | 0 | 0 (0) | 0 |
| search | claude-sonnet-5-5@low | on | 6/6 | 100%–100% | outcome 6/6 · coverage 4/4 · scope 6/6 | – | 83 | 45% / 53% / 2% | $0.0131 | $0.0089–$0.0139 | 3.0 | 18702 | 11889–19190 | 84% | 71 | 93% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search | claude-sonnet-5-5@high | on | 6/6 | 100%–100% | outcome 6/6 · coverage 4/4 · scope 6/6 | – | 94 | 40% / 58% / 2% | $0.0135 | $0.0112–$0.0162 | 3.0 | 18868 | 18267–19824 | 84% | 86 | 91% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search | claude-sonnet-5-5@medium | on | 6/6 | 100%–100% | outcome 6/6 · coverage 4/4 · scope 6/6 | – | 72 | 40% / 57% / 3% | $0.0139 | $0.0088–$0.0153 | 3.0 | 19090 | 11867–25507 | 85% | 73 | 92% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search | claude-sonnet-5-5@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · coverage 4/4 · scope 6/6 | – | 99 | 45% / 49% / 6% | $0.0145 | $0.0119–$0.0170 | 3.0 | 19001 | 18695–19975 | 84% | 76 | 90% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search | claude-opus-5-5@medium | on | 6/6 | 100%–100% | outcome 6/6 · coverage 4/4 · scope 6/6 | – | 99 | 51% / 47% / 2% | $0.0281 | $0.0235–$0.0403 | 3.0 | 18748 | 18367–27858 | 85% | 60 | 93% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search | claude-opus-5-5@low | on | 6/6 | 100%–100% | outcome 6/6 · coverage 4/4 · scope 6/6 | – | 84 | 43% / 51% / 6% | $0.0287 | $0.0227–$0.0311 | 3.0 | 19157 | 18230–24941 | 86% | 61 | 93% | 3 | 0% | 0 | 0 | 0 (0) | 0 |
| search | claude-opus-5-5@high | on | 6/6 | 100%–100% | outcome 6/6 · coverage 4/4 · scope 6/6 | – | 86 | 33% / 66% / 2% | $0.0302 | $0.0246–$0.0327 | 3.0 | 19187 | 18544–19750 | 84% | 72 | 93% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search | claude-opus-5-5@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · coverage 4/4 · scope 6/6 | – | 110 | 40% / 58% / 2% | $0.0328 | $0.0279–$0.0368 | 3.0 | 19520 | 19131–20983 | 83% | 63 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search-hard | gpt-6.1-terra@medium | on | 2/2 | 100%–100% | outcome 2/2 · scope 2/2 | – | 80 | 7% / 80% / 13% | $0.0108 | $0.0057–$0.0159 | 4.0 | 15543 | 12406–18679 | 80% | 29 | 68% | 0 | 13% | 0 | 0 | 1 (0) | 0 |
| search-hard | gpt-6.1-terra@high | on | 2/2 | 100%–100% | outcome 2/2 · scope 2/2 | – | 72 | 8% / 92% / 0% | $0.0109 | $0.0056–$0.0162 | 3.5 | 14078 | 12506–15650 | 76% | 32 | 66% | 0 | 29% | 0 | 0 | 1 (0) | 0 |
| search-hard | gpt-6.1-terra@xhigh | on | 2/2 | 100%–100% | outcome 2/2 · scope 2/2 | – | 74 | 7% / 78% / 15% | $0.0118 | $0.0051–$0.0184 | 4.5 | 18681 | 11817–25545 | 85% | 37 | 74% | 0 | 44% | 0 | 0 | 1 (0) | 0 |
| search-hard | gpt-6.1-terra@low | on | 2/2 | 100%–100% | outcome 2/2 · scope 2/2 | – | 66 | 8% / 92% / 0% | $0.0132 | $0.0062–$0.0201 | 4.0 | 15749 | 11806–19692 | 82% | 29 | 61% | 0 | 25% | 0 | 0 | 1 (0) | 0 |
| search-hard | claude-sonnet-5-5@medium | on | 3/4 | 50%–100% | outcome 3/4 · scope 4/4 | – | 85 | 7% / 69% / 25% | $0.0180 | $0.0176–$0.0189 | 3.0 | 20965 | 20938–21381 | 78% | 69 | 92% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search-hard | claude-sonnet-5-5@low | on | 3/4 | 50%–100% | outcome 3/4 · scope 4/4 | – | 94 | 6% / 90% / 4% | $0.0181 | $0.0174–$0.0182 | 3.0 | 20926 | 20760–21006 | 79% | 71 | 92% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search-hard | claude-sonnet-5-5@high | on | 4/4 | 100%–100% | outcome 4/4 · scope 4/4 | – | 139 | 4% / 95% / 1% | $0.0217 | $0.0185–$0.0255 | 3.0 | 21298 | 21034–22035 | 78% | 78 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search-hard | claude-sonnet-5-5@xhigh | on | 4/4 | 100%–100% | outcome 4/4 · scope 4/4 | – | 165 | 3% / 96% / 1% | $0.0251 | $0.0224–$0.0282 | 3.0 | 21596 | 21163–22322 | 78% | 87 | 95% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search-hard | claude-opus-5-5@low | on | 4/4 | 100%–100% | outcome 4/4 · scope 4/4 | – | 156 | 4% / 96% / 1% | $0.0419 | $0.0379–$0.0470 | 3.0 | 21466 | 21118–21821 | 78% | 66 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search-hard | claude-opus-5-5@medium | on | 4/4 | 100%–100% | outcome 4/4 · scope 4/4 | – | 158 | 3% / 95% / 2% | $0.0447 | $0.0410–$0.0488 | 3.0 | 21530 | 21114–21927 | 78% | 63 | 94% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search-hard | claude-opus-5-5@high | on | 4/4 | 100%–100% | outcome 4/4 · scope 4/4 | – | 192 | 3% / 96% / 1% | $0.0514 | $0.0507–$0.0558 | 3.5 | 26153 | 22210–31187 | 79% | 68 | 95% | 0 | 0% | 0 | 0 | 0 (0) | 0 |
| search-hard | claude-opus-5-5@xhigh | on | 4/4 | 100%–100% | outcome 4/4 · scope 4/4 | – | 194 | 3% / 94% / 3% | $0.0625 | $0.0548–$0.0756 | 3.5 | 27633 | 21966–34317 | 77% | 75 | 96% | 1 | 0% | 0 | 0 | 0 (0) | 0 |
| small-fix | gpt-6.1-terra@medium | on | 3/3 | 100%–100% | outcome 3/3 · coverage 3/3 · scope 3/3 · hidden 3/3 | – | 25 | 62% / 38% / 0% | $0.0053 | $0.0038–$0.0060 | 6.0 | 20831 | 20185–21841 | 86% | 28 | 95% | 3 | 6% | 0 | 0 | 0 (0) | 0 |
| small-fix | gpt-6.1-terra@high | on | 3/3 | 100%–100% | outcome 3/3 · coverage 3/3 · scope 3/3 · hidden 3/3 | – | 22 | 66% / 34% / 0% | $0.0055 | $0.0040–$0.0057 | 6.0 | 21263 | 20753–22369 | 88% | 21 | 96% | 3 | 18% | 0 | 0 | 0 (0) | 0 |
| small-fix | gpt-6.1-terra@low | on | 3/3 | 100%–100% | outcome 3/3 · coverage 3/3 · scope 3/3 · hidden 3/3 | – | 23 | 65% / 35% / 0% | $0.0068 | $0.0041–$0.0093 | 6.0 | 20616 | 19385–21769 | 76% | 26 | 96% | 3 | 6% | 0 | 0 | 0 (0) | 0 |
| small-fix | gpt-6.1-terra@xhigh | on | 3/3 | 100%–100% | outcome 3/3 · coverage 3/3 · scope 3/3 · hidden 3/3 | – | 21 | 64% / 36% / 0% | $0.0068 | $0.0061–$0.0084 | 6.0 | 21611 | 20827–22653 | 78% | 24 | 97% | 3 | 18% | 0 | 0 | 0 (0) | 0 |
| small-fix | claude-sonnet-5-5@low | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 45 | 85% / 12% / 3% | $0.0148 | $0.0126–$0.0175 | 5.0 | 31842 | 18399–33236 | 89% | 74 | 90% | 4 | 4% | 0 | 0 | 0 (0) | 0 |
| small-fix | claude-sonnet-5-5@medium | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 40 | 84% / 16% / 0% | $0.0155 | $0.0144–$0.0172 | 5.0 | 32159 | 19435–33278 | 89% | 77 | 90% | 3 | 4% | 0 | 0 | 0 (0) | 0 |
| small-fix | claude-sonnet-5-5@high | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 39 | 89% / 11% / 0% | $0.0170 | $0.0146–$0.0184 | 5.0 | 32481 | 19786–33555 | 89% | 75 | 91% | 4 | 11% | 0 | 0 | 0 (0) | 0 |
| small-fix | claude-sonnet-5-5@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 47 | 84% / 16% / 0% | $0.0175 | $0.0171–$0.0205 | 4.0 | 28509 | 27240–40560 | 88% | 77 | 91% | 2 | 11% | 0 | 0 | 0 (0) | 0 |
| small-fix | claude-opus-5-5@low | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 71 | 76% / 15% / 9% | $0.0270 | $0.0261–$0.0318 | 3.0 | 19487 | 19259–25347 | 86% | 69 | 90% | 0 | 10% | 0 | 0 | 0 (0) | 0 |
| small-fix | claude-opus-5-5@medium | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 74 | 83% / 15% / 1% | $0.0326 | $0.0287–$0.0401 | 4.0 | 26290 | 25637–27584 | 87% | 72 | 92% | 0 | 25% | 0 | 0 | 0 (0) | 0 |
| small-fix | claude-opus-5-5@high | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 79 | 84% / 16% / 0% | $0.0332 | $0.0289–$0.0436 | 4.0 | 26317 | 25720–35209 | 88% | 70 | 93% | 0 | 20% | 0 | 0 | 0 (0) | 0 |
| small-fix | claude-opus-5-5@xhigh | on | 6/6 | 100%–100% | outcome 6/6 · coverage 6/6 · scope 6/6 · hidden 6/6 | – | 95 | 77% / 13% / 10% | $0.0409 | $0.0304–$0.0486 | 4.0 | 28009 | 26472–34878 | 87% | 70 | 93% | 0 | 19% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | gpt-6.1-terra@low | on | 2/2 | 100%–100% | outcome 2/2 · coverage 2/2 · scope 2/2 · hidden 2/2 | – | 35 | 74% / 26% / 0% | $0.0043 | $0.0032–$0.0054 | 5.5 | 20444 | 12875–28012 | 89% | 26 | 95% | 1 | 0% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | gpt-6.1-terra@medium | on | 2/2 | 100%–100% | outcome 2/2 · coverage 2/2 · scope 2/2 · hidden 2/2 | – | 33 | 73% / 27% / 0% | $0.0070 | $0.0056–$0.0085 | 5.0 | 19077 | 13115–25039 | 75% | 26 | 96% | 1 | 10% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | gpt-6.1-terra@high | on | 2/2 | 100%–100% | outcome 2/2 · coverage 2/2 · scope 2/2 · hidden 2/2 | – | 31 | 76% / 24% / 0% | $0.0080 | $0.0066–$0.0093 | 5.0 | 20347 | 14878–25815 | 75% | 21 | 97% | 1 | 20% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | gpt-6.1-terra@xhigh | on | 2/2 | 100%–100% | outcome 2/2 · coverage 2/2 · scope 2/2 · hidden 2/2 | – | 32 | 89% / 11% / 0% | $0.0096 | $0.0092–$0.0099 | 5.5 | 24003 | 21018–26987 | 81% | 34 | 98% | 1 | 36% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | claude-sonnet-5-5@low | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 79 | 74% / 25% / 1% | $0.0173 | $0.0152–$0.0198 | 4.0 | 26839 | 19665–35220 | 87% | 78 | 90% | 1 | 25% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | claude-sonnet-5-5@medium | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 82 | 70% / 30% / 0% | $0.0182 | $0.0145–$0.0209 | 4.0 | 27631 | 19520–41480 | 88% | 87 | 90% | 1 | 18% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | claude-sonnet-5-5@high | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 79 | 66% / 32% / 2% | $0.0190 | $0.0156–$0.0231 | 4.0 | 27861 | 19752–43715 | 87% | 94 | 91% | 3 | 24% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | claude-sonnet-5-5@xhigh | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 96 | 68% / 13% / 19% | $0.0243 | $0.0232–$0.0255 | 4.0 | 29067 | 28621–29590 | 84% | 106 | 90% | 0 | 13% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | claude-opus-5-5@low | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 121 | 53% / 40% / 7% | $0.0305 | $0.0282–$0.0319 | 3.0 | 19495 | 19223–19745 | 84% | 83 | 91% | 0 | 17% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | claude-opus-5-5@medium | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 140 | 58% / 38% / 4% | $0.0376 | $0.0363–$0.0388 | 3.5 | 23892 | 20041–27829 | 85% | 79 | 93% | 0 | 29% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | claude-opus-5-5@high | on | 4/4 | 100%–100% | outcome 4/4 · coverage 4/4 · scope 4/4 · hidden 4/4 | – | 132 | 76% / 24% / 0% | $0.0393 | $0.0371–$0.0415 | 4.0 | 27518 | 26880–27801 | 86% | 76 | 94% | 0 | 13% | 0 | 0 | 0 (0) | 0 |
| small-fix-hard | claude-opus-5-5@xhigh | on | 3/4 | 50%–100% | outcome 4/4 · coverage 3/4 · scope 4/4 · hidden 4/4 | – | 146 | 51% / 41% / 8% | $0.0547 | $0.0507–$0.0602 | 4.5 | 33095 | 30264–35611 | 85% | 84 | 95% | 0 | 22% | 0 | 0 | 0 (0) | 0 |

## Threshold per class (lowest median cost among arms whose worst repetition reaches 90% in strict passes)

- multi-file: gpt-6.1-terra@high at $0.0104/run
- multi-file-hard: claude-sonnet-5-5@medium at $0.0296/run
- review: gpt-6.1-terra@xhigh at $0.0017/run
- review-hard: gpt-6.1-terra@high at $0.0014/run
- search: gpt-6.1-terra@medium at $0.0030/run
- search-hard: gpt-6.1-terra@medium at $0.0108/run
- small-fix: gpt-6.1-terra@medium at $0.0053/run
- small-fix-hard: gpt-6.1-terra@low at $0.0043/run

## Drops by effort

Strict passes per effort, lowest first; ★ the best effort of the row. Against it, paired by task and repetition: the change in pass rate, the runs lost, ▼ when the loss is beyond the noise (replicate arms) or at least 2 runs without replicates, and what got worse with it.

- multi-file · anthropic/claude-opus-5-5: low 6/6 ★ │ medium 6/6 │ high 6/6 │ xhigh 6/6
- multi-file · anthropic/claude-sonnet-5-5: low 6/6 ★ │ medium 6/6 │ high 6/6 │ xhigh 6/6
- multi-file · openai/gpt-6.1-terra: low 6/6 ★ │ medium 6/6 │ high 6/6 │ xhigh 6/6
- multi-file-hard · anthropic/claude-opus-5-5: low 4/4 ★ │ medium 4/4 │ high 4/4 │ xhigh 4/4
- multi-file-hard · anthropic/claude-sonnet-5-5: low 4/4 ★ │ medium 4/4 │ high 4/4 │ xhigh 4/4
- multi-file-hard · openai/gpt-6.1-terra: low 3/3 ★ │ medium 3/3 │ high 3/3 │ xhigh 3/3
- review · anthropic/claude-opus-5-5: low 6/6 ★ │ medium 6/6 │ high 6/6 │ xhigh 6/6
- review · anthropic/claude-sonnet-5-5: low 4/6 (-33pp, lost 2 ▼; citation −2, extra findings +2) │ medium 3/6 (-50pp, lost 3 ▼; citation −3, extra findings +3) │ high 3/6 (-50pp, lost 3 ▼; citation −3, extra findings +3) │ xhigh 6/6 ★
- review · openai/gpt-6.1-terra: low 3/3 ★ │ medium 3/3 │ high 3/3 │ xhigh 3/3
- review-hard · anthropic/claude-opus-5-5: low 4/4 ★ │ medium 4/4 │ high 4/4 │ xhigh 4/4
- review-hard · anthropic/claude-sonnet-5-5: low 4/4 ★ │ medium 4/4 │ high 3/4 (-25pp, lost 1; citation −1, extra findings +1) │ xhigh 4/4
- review-hard · openai/gpt-6.1-terra: low 3/3 ★ │ medium 3/3 │ high 3/3 │ xhigh 2/2
- search · anthropic/claude-opus-5-5: low 6/6 ★ │ medium 6/6 │ high 6/6 │ xhigh 6/6
- search · anthropic/claude-sonnet-5-5: low 6/6 ★ │ medium 6/6 │ high 6/6 │ xhigh 6/6
- search · openai/gpt-6.1-terra: low 3/3 ★ │ medium 3/3 │ high 3/3 │ xhigh 3/3
- search-hard · anthropic/claude-opus-5-5: low 4/4 ★ │ medium 4/4 │ high 4/4 │ xhigh 4/4
- search-hard · anthropic/claude-sonnet-5-5: low 3/4 (-25pp, lost 1; outcome −1) │ medium 3/4 (-25pp, lost 1; outcome −1) │ high 4/4 ★ │ xhigh 4/4
- search-hard · openai/gpt-6.1-terra: low 2/2 ★ │ medium 2/2 │ high 2/2 │ xhigh 2/2
- small-fix · anthropic/claude-opus-5-5: low 6/6 ★ │ medium 6/6 │ high 6/6 │ xhigh 6/6
- small-fix · anthropic/claude-sonnet-5-5: low 6/6 ★ │ medium 6/6 │ high 6/6 │ xhigh 6/6
- small-fix · openai/gpt-6.1-terra: low 3/3 ★ │ medium 3/3 │ high 3/3 │ xhigh 3/3
- small-fix-hard · anthropic/claude-opus-5-5: low 4/4 ★ │ medium 4/4 │ high 4/4 │ xhigh 3/4 (-25pp, lost 1; coverage −1)
- small-fix-hard · anthropic/claude-sonnet-5-5: low 4/4 ★ │ medium 4/4 │ high 4/4 │ xhigh 4/4
- small-fix-hard · openai/gpt-6.1-terra: low 2/2 ★ │ medium 2/2 │ high 2/2 │ xhigh 2/2

## Effort saturation (lowest effort with the best strict pass rate)

- multi-file · openai/gpt-6.1-terra: low (100%)
- multi-file · anthropic/claude-sonnet-5-5: low (100%)
- multi-file · anthropic/claude-opus-5-5: low (100%)
- multi-file-hard · anthropic/claude-sonnet-5-5: low (100%)
- multi-file-hard · openai/gpt-6.1-terra: low (100%)
- multi-file-hard · anthropic/claude-opus-5-5: low (100%)
- review · openai/gpt-6.1-terra: low (100%)
- review · anthropic/claude-sonnet-5-5: xhigh (100%)
- review · anthropic/claude-opus-5-5: low (100%)
- review-hard · openai/gpt-6.1-terra: low (100%)
- review-hard · anthropic/claude-sonnet-5-5: low (100%)
- review-hard · anthropic/claude-opus-5-5: low (100%)
- search · openai/gpt-6.1-terra: low (100%)
- search · anthropic/claude-sonnet-5-5: low (100%)
- search · anthropic/claude-opus-5-5: low (100%)
- search-hard · openai/gpt-6.1-terra: low (100%)
- search-hard · anthropic/claude-sonnet-5-5: high (100%)
- search-hard · anthropic/claude-opus-5-5: low (100%)
- small-fix · openai/gpt-6.1-terra: low (100%)
- small-fix · anthropic/claude-sonnet-5-5: low (100%)
- small-fix · anthropic/claude-opus-5-5: low (100%)
- small-fix-hard · openai/gpt-6.1-terra: low (100%)
- small-fix-hard · anthropic/claude-sonnet-5-5: low (100%)
- small-fix-hard · anthropic/claude-opus-5-5: low (100%)

Differences smaller than the spread between replicate arms of the same model are noise.
