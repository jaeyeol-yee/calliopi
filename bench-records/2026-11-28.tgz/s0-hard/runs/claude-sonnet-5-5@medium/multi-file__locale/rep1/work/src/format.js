// Euros from cents.
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale === 'de') {
    const [int, dec] = fixed.split('.');
    const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return `${grouped},${dec} €`;
  }
  return `€${fixed}`;
}
module.exports = { formatPrice };
