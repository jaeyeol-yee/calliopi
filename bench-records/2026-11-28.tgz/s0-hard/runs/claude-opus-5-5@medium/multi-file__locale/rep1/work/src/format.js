// Euros from cents. locale: 'en' (default, e.g. €2011.50) or 'de' (e.g. 2.011,50 €).
function formatPrice(cents, locale = 'en') {
  if (locale === 'en') return `€${(cents / 100).toFixed(2)}`;
  if (locale === 'de') {
    const [int, frac] = (Math.abs(cents) / 100).toFixed(2).split('.');
    const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return `${cents < 0 ? '-' : ''}${grouped},${frac} €`;
  }
  throw new RangeError(`Unsupported locale: ${locale}`);
}
module.exports = { formatPrice };
