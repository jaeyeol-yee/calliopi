# Benchmark: s0-hard

- Pi 1.6.0 · harness 40444c4 · tasks search/trace-port@v1, small-fix/thousands@v1, multi-file/locale@v1, review/pagination@v1
- 12 runs, $0.28 total

## By arm and task class

Cost, turns and tokens are medians per run; ranges are min–max.

| class | arm | harness | pass | worst–best rep | $/run | $ range | turns | tokens | tokens range | cache hit | tool errors | parallel | out of scope | timeouts |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| multi-file | gpt-6.1-terra@medium | on | 1/1 | 100%–100% | $0.0171 | $0.0171–$0.0171 | 7.0 | 27682 | 27682–27682 | 52% | 0 | 29% | 0 | 0 |
| multi-file | claude-sonnet-5-5@medium | on | 1/1 | 100%–100% | $0.0280 | $0.0280–$0.0280 | 6.0 | 43568 | 43568–43568 | 90% | 0 | 0% | 0 | 0 |
| multi-file | claude-opus-5-5@medium | on | 1/1 | 100%–100% | $0.0519 | $0.0519–$0.0519 | 4.0 | 29135 | 29135–29135 | 85% | 1 | 0% | 0 | 0 |
| review | gpt-6.1-terra@medium | on | 1/1 | 100%–100% | $0.0082 | $0.0082–$0.0082 | 4.0 | 12558 | 12558–12558 | 47% | 0 | 0% | 0 | 0 |
| review | claude-sonnet-5-5@medium | on | 0/1 | 0%–0% | $0.0093 | $0.0093–$0.0093 | 2.0 | 11841 | 11841–11841 | 82% | 0 | 0% | 0 | 0 |
| review | claude-opus-5-5@medium | on | 1/1 | 100%–100% | $0.0235 | $0.0235–$0.0235 | 2.0 | 12090 | 12090–12090 | 82% | 0 | 0% | 0 | 0 |
| search | gpt-6.1-terra@medium | on | 1/1 | 100%–100% | $0.0085 | $0.0085–$0.0085 | 4.0 | 13199 | 13199–13199 | 48% | 0 | 25% | 0 | 0 |
| search | claude-sonnet-5-5@medium | on | 1/1 | 100%–100% | $0.0225 | $0.0225–$0.0225 | 3.0 | 18859 | 18859–18859 | 64% | 0 | 0% | 0 | 0 |
| search | claude-opus-5-5@medium | on | 1/1 | 100%–100% | $0.0443 | $0.0443–$0.0443 | 3.0 | 18297 | 18297–18297 | 64% | 0 | 0% | 0 | 0 |
| small-fix | gpt-6.1-terra@medium | on | 1/1 | 100%–100% | $0.0130 | $0.0130–$0.0130 | 8.0 | 30570 | 30570–30570 | 67% | 1 | 13% | 0 | 0 |
| small-fix | claude-sonnet-5-5@medium | on | 1/1 | 100%–100% | $0.0175 | $0.0175–$0.0175 | 5.0 | 33198 | 33198–33198 | 90% | 1 | 20% | 0 | 0 |
| small-fix | claude-opus-5-5@medium | on | 1/1 | 100%–100% | $0.0320 | $0.0320–$0.0320 | 4.0 | 26144 | 26144–26144 | 88% | 0 | 25% | 0 | 0 |

## Threshold per class (lowest median cost among arms whose worst repetition reaches 90%)

- multi-file: gpt-6.1-terra@medium at $0.0171/run
- review: gpt-6.1-terra@medium at $0.0082/run
- search: gpt-6.1-terra@medium at $0.0085/run
- small-fix: gpt-6.1-terra@medium at $0.0130/run

Differences smaller than the spread between replicate arms of the same model are noise.
