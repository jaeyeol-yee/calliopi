# Benchmark: s0-cache

- Pi 1.6.0 · harness c7b2dea · tasks small-fix/off-by-one@v1, search/find-default@v1
- 24 runs, $0.63 total

## By arm and task class

| class | arm | harness | pass | worst–best rep | $/run | turns | tokens | cache hit | tool errors | parallel | out of scope | timeouts |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| search | gpt-6.1-terra@medium | on | 4/4 | 100%–100% | $0.0065 | 3.0 | 9149 | 38% | 0 | 33% | 0 | 0 |
| search | gpt-6.2-sol@medium | on | 4/4 | 100%–100% | $0.0149 | 3.0 | 9209 | 26% | 0 | 17% | 0 | 0 |
| search | gpt-6.2-astra@medium | on | 4/4 | 100%–100% | $0.0411 | 2.3 | 6789 | 31% | 0 | 0% | 0 | 0 |
| small-fix | gpt-6.1-terra@medium | on | 4/4 | 100%–100% | $0.0098 | 6.0 | 20985 | 62% | 4 | 13% | 0 | 0 |
| small-fix | gpt-6.2-sol@medium | on | 4/4 | 100%–100% | $0.0194 | 6.0 | 20176 | 60% | 4 | 0% | 0 | 0 |
| small-fix | gpt-6.2-astra@medium | on | 4/4 | 100%–100% | $0.0666 | 5.0 | 17539 | 60% | 4 | 0% | 0 | 0 |

## Threshold per class (cheapest arm whose worst repetition reaches 90%)

- search: gpt-6.1-terra@medium at $0.0065/run
- small-fix: gpt-6.1-terra@medium at $0.0098/run

Differences smaller than the spread between replicate arms of the same model are noise.
