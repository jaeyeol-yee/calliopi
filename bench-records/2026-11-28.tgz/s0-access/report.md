# Benchmark: s0-access

- Pi 1.6.0 · harness c74b07f · tasks search/find-default@v1
- 7 runs, $0.20 total

## By arm and task class

| class | arm | harness | pass | worst–best rep | $/run | turns | tokens | cache hit | tool errors | parallel | out of scope | timeouts |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| search | gpt-6.1-terra@medium | on | 1/1 | 100%–100% | $0.0041 | 3.0 | 9001 | 62% | 0 | 0% | 0 | 0 |
| search | claude-sonnet-5-5@medium | on | 1/1 | 100%–100% | $0.0180 | 2.0 | 11825 | 48% | 0 | 0% | 0 | 0 |
| search | gpt-6.2-sol@medium | on | 1/1 | 100%–100% | $0.0189 | 3.0 | 9017 | 0% | 0 | 0% | 0 | 0 |
| search | claude-opus-5-5@medium-bare | off | 1/1 | 100%–100% | $0.0254 | 3.0 | 8950 | 62% | 0 | 0% | 0 | 0 |
| search | claude-opus-5-5@medium | on | 1/1 | 100%–100% | $0.0414 | 3.0 | 18229 | 65% | 0 | 0% | 0 | 0 |
| search | claude-fable-5-2@medium | on | 1/1 | 100%–100% | $0.0416 | 3.0 | 18215 | 86% | 0 | 0% | 0 | 0 |
| search | gpt-6.2-astra@medium | on | 1/1 | 100%–100% | $0.0500 | 2.0 | 5972 | 0% | 0 | 0% | 0 | 0 |

## Threshold per class (cheapest arm whose worst repetition reaches 90%)

- search: gpt-6.1-terra@medium at $0.0041/run

Differences smaller than the spread between replicate arms of the same model are noise.
