const store = require('./store');
// Retries transient read errors up to `times` attempts in total.
async function readWithRetry(key, times) {
  try {
    return await store.read(key);
  } catch (err) {
    if (err.message === 'transient' && times > 1) return readWithRetry(key, times - 1);
    throw err;
  }
}
module.exports = { readWithRetry };
