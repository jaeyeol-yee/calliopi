const { readWithRetry } = require('./retry');
async function nextCount() {
  return Number(await readWithRetry('count', 2)) + 1;
}
module.exports = { nextCount };
