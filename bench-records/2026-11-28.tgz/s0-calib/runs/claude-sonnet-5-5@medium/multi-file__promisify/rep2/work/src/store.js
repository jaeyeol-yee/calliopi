// An in-memory store with a promise API. Reads of a missing key fail.
const data = new Map([['greeting', 'hello'], ['count', '3']]);
let failNext = 0;
function read(key) {
  return new Promise((resolve, reject) => {
    setImmediate(() => {
      if (failNext > 0) { failNext--; return reject(new Error('transient')); }
      if (!data.has(key)) return reject(new Error(`missing ${key}`));
      resolve(data.get(key));
    });
  });
}
function failTimes(n) { failNext = n; }
module.exports = { read, failTimes };
