# Benchmark: s0-calib

- Pi 1.6.0 · harness c6ccaf6 · tasks search/direct-callers@v1, small-fix/lru@v1, multi-file/promisify@v1, review/duration@v1
- 24 runs, $0.58 total

## By arm and task class

Cost includes subagents. Cost, turns and tokens (the run's own) are medians per run; ranges are min–max.

| class | arm | harness | pass | worst–best rep | $/run | $ range | turns | tokens | tokens range | cache hit | tool errors | parallel | out of scope | timeouts | subagents (stopped) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| multi-file | gpt-6.1-terra@medium | on | 2/2 | 100%–100% | $0.0161 | $0.0152–$0.0170 | 11.5 | 51631 | 49307–53955 | 84% | 0 | 13% | 0 | 0 | 2 (2) |
| multi-file | claude-sonnet-5-5@medium | on | 2/2 | 100%–100% | $0.0237 | $0.0206–$0.0268 | 4.0 | 29253 | 20865–37640 | 85% | 0 | 13% | 0 | 0 | 0 (0) |
| multi-file | claude-opus-5-5@medium | on | 2/2 | 100%–100% | $0.0511 | $0.0507–$0.0515 | 4.0 | 29893 | 29880–29906 | 85% | 2 | 0% | 0 | 0 | 0 (0) |
| review | claude-sonnet-5-5@medium | on | 0/2 | 0%–0% | $0.0122 | $0.0104–$0.0140 | 2.0 | 12253 | 12075–12430 | 81% | 0 | 0% | 0 | 0 | 0 (0) |
| review | claude-opus-5-5@medium | on | 2/2 | 100%–100% | $0.0321 | $0.0300–$0.0342 | 2.0 | 12640 | 12533–12746 | 81% | 0 | 0% | 0 | 0 | 0 (0) |
| review | gpt-6.1-terra@medium | on | 0/2 | 0%–0% | $0.0334 | $0.0325–$0.0343 | 6.0 | 21884 | 21625–22143 | 53% | 0 | 0% | 0 | 0 | 4 (0) |
| search | gpt-6.1-terra@medium | on | 2/2 | 100%–100% | $0.0056 | $0.0056–$0.0056 | 4.0 | 13096 | 13091–13101 | 69% | 0 | 25% | 0 | 0 | 0 (0) |
| search | claude-sonnet-5-5@medium | on | 2/2 | 100%–100% | $0.0181 | $0.0134–$0.0229 | 3.0 | 18991 | 18890–19092 | 74% | 0 | 0% | 0 | 0 | 0 (0) |
| search | claude-opus-5-5@medium | on | 2/2 | 100%–100% | $0.0400 | $0.0305–$0.0495 | 3.0 | 19562 | 19550–19574 | 72% | 0 | 0% | 0 | 0 | 0 (0) |
| small-fix | gpt-6.1-terra@medium | on | 2/2 | 100%–100% | $0.0051 | $0.0046–$0.0056 | 4.5 | 16337 | 12672–20001 | 81% | 1 | 0% | 0 | 0 | 0 (0) |
| small-fix | claude-sonnet-5-5@medium | on | 2/2 | 100%–100% | $0.0144 | $0.0139–$0.0148 | 3.0 | 19358 | 19297–19419 | 84% | 0 | 0% | 0 | 0 | 0 (0) |
| small-fix | claude-opus-5-5@medium | on | 2/2 | 100%–100% | $0.0382 | $0.0372–$0.0392 | 4.5 | 30849 | 27195–34502 | 88% | 0 | 11% | 0 | 0 | 0 (0) |

## Threshold per class (lowest median cost among arms whose worst repetition reaches 90%)

- multi-file: gpt-6.1-terra@medium at $0.0161/run
- review: claude-opus-5-5@medium at $0.0321/run
- search: gpt-6.1-terra@medium at $0.0056/run
- small-fix: gpt-6.1-terra@medium at $0.0051/run

Differences smaller than the spread between replicate arms of the same model are noise.
