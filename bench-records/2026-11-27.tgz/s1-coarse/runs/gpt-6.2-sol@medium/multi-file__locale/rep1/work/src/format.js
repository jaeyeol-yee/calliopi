// Euros from cents.
function formatPrice(cents, locale = 'en') {
  const amount = (cents / 100).toFixed(2);
  if (locale === 'de') {
    const localized = amount.replace(/^(-?\d+)\.(\d{2})$/, (_, whole, fraction) =>
      `${whole.replace(/\B(?=(\d{3})+(?!\d))/g, '.')},${fraction}`
    );
    return `${localized} €`;
  }
  return `€${amount}`;
}
module.exports = { formatPrice };
