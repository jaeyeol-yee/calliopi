// Euros from cents.
function formatPrice(cents, locale = 'en') {
  const amount = (cents / 100).toFixed(2);
  if (locale === 'de') {
    const [euros, fraction] = amount.split('.');
    const grouped = euros.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return `${grouped},${fraction} €`;
  }
  return `€${amount}`;
}
module.exports = { formatPrice };
