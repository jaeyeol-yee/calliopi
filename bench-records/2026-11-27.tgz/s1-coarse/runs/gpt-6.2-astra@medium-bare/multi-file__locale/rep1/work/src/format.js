// Euros from cents.
function formatPrice(cents, locale = 'en') {
  const amount = (cents / 100).toFixed(2);
  if (locale === 'de') {
    const [whole, fraction] = amount.split('.');
    const grouped = whole.replace(/\B(?=(\d{3})+$)/g, '.');
    return `${grouped},${fraction} €`;
  }
  return `€${amount}`;
}
module.exports = { formatPrice };
