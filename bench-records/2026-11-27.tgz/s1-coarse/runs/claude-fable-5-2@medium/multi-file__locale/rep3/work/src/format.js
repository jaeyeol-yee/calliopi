// Euros from cents. locale: 'en' (default) -> "€2011.50", 'de' -> "2.011,50 €".
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale === 'en') return `€${fixed}`;
  if (locale === 'de') {
    const [whole, frac] = fixed.split('.');
    const grouped = whole.replace(/\B(?=(\d{3})+$)/g, '.');
    return `${grouped},${frac} €`;
  }
  throw new RangeError(`Unsupported locale: ${locale}`);
}
module.exports = { formatPrice };
