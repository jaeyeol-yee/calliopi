// Euros from cents. locale: 'en' (default) or 'de'.
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale === 'en') return `€${fixed}`;
  if (locale === 'de') {
    const [, sign, int, frac] = fixed.match(/^(-?)(\d+)\.(\d+)$/);
    const grouped = int.replace(/\B(?=(\d{3})+$)/g, '.');
    return `${sign}${grouped},${frac} €`;
  }
  throw new RangeError(`Unsupported locale: ${locale}`);
}
module.exports = { formatPrice };
