// Euros from cents. locale: 'en' (default) or 'de'.
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale === 'de') {
    const [int, frac] = fixed.split('.');
    const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return `${grouped},${frac} €`;
  }
  return `€${fixed}`;
}
module.exports = { formatPrice };
