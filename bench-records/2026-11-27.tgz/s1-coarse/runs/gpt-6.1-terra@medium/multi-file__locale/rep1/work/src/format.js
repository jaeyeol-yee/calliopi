// Euros from cents.
function formatPrice(cents, locale = 'en') {
  const amount = (cents / 100).toFixed(2);
  if (locale === 'de') {
    const [whole, fractional] = amount.split('.');
    return `${whole.replace(/\B(?=(\d{3})+(?!\d))/g, '.')},${fractional} €`;
  }
  return `€${amount}`;
}
module.exports = { formatPrice };
