// Euros from cents. locale: 'en' (default) or 'de'.
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale === 'de') {
    const neg = fixed.startsWith('-');
    const [int, dec] = (neg ? fixed.slice(1) : fixed).split('.');
    return `${neg ? '-' : ''}${int.replace(/\B(?=(\d{3})+$)/g, '.')},${dec} €`;
  }
  return `€${fixed}`;
}
module.exports = { formatPrice };
