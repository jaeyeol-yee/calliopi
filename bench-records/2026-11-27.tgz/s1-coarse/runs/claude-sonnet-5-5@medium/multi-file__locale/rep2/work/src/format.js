// Euros from cents.
function formatPrice(cents, locale = 'en') {
  const fixed = (cents / 100).toFixed(2);
  if (locale !== 'de') return `€${fixed}`;
  const neg = fixed.startsWith('-');
  const [int, dec] = fixed.replace('-', '').split('.');
  const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${neg ? '-' : ''}${grouped},${dec} €`;
}
module.exports = { formatPrice };
