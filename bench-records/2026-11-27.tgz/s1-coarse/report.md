# Benchmark: s1-coarse

- Pi 1.6.0 · harness 19c14d4 · tasks multi-file/locale@v1, multi-file/rename-option@v1, review/pagination@v2, review/spot-bug@v1, search/find-default@v1, search/trace-port@v1, small-fix/off-by-one@v1, small-fix/thousands@v1
- 216 runs, $7.83 total

## By arm and task class

Cost includes subagents. Cost, turns and tokens (the run's own) are medians per run; ranges are min–max.

| class | arm | harness | pass | worst–best rep | $/run | $ range | turns | tokens | tokens range | cache hit | tool errors | parallel | out of scope | timeouts | subagents (stopped) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| multi-file | gpt-6.1-terra@medium | on | 6/6 | 100%–100% | $0.0135 | $0.0084–$0.0181 | 8.0 | 28495 | 27187–32833 | 74% | 0 | 15% | 0 | 0 | 6 (6) |
| multi-file | claude-sonnet-5-5@medium | on | 6/6 | 100%–100% | $0.0205 | $0.0127–$0.0294 | 5.0 | 33973 | 24216–43961 | 90% | 3 | 0% | 0 | 0 | 0 (0) |
| multi-file | gpt-6.2-sol@medium | on | 6/6 | 100%–100% | $0.0301 | $0.0269–$0.0580 | 6.5 | 24345 | 22400–38821 | 60% | 2 | 27% | 0 | 0 | 6 (5) |
| multi-file | claude-opus-5-5@medium | on | 6/6 | 100%–100% | $0.0427 | $0.0371–$0.0477 | 4.5 | 31383 | 28054–34056 | 87% | 6 | 0% | 0 | 0 | 0 (0) |
| multi-file | opus-5-5@medium-replicate | on | 6/6 | 100%–100% | $0.0449 | $0.0368–$0.0516 | 5.0 | 33937 | 28865–35377 | 87% | 6 | 0% | 0 | 0 | 0 (0) |
| multi-file | gpt-6.2-astra@medium-bare | off | 6/6 | 100%–100% | $0.0656 | $0.0421–$0.0932 | 5.0 | 10087 | 7338–12447 | 43% | 0 | 38% | 0 | 0 | 0 (0) |
| multi-file | claude-fable-5-2@medium-bare | off | 6/6 | 100%–100% | $0.0731 | $0.0494–$0.11 | 4.5 | 17791 | 14076–21675 | 78% | 2 | 0% | 0 | 0 | 0 (0) |
| multi-file | claude-fable-5-2@medium | on | 6/6 | 100%–100% | $0.0855 | $0.0600–$0.11 | 5.0 | 35869 | 26777–43876 | 88% | 2 | 3% | 0 | 0 | 0 (0) |
| multi-file | gpt-6.2-astra@medium | on | 6/6 | 100%–100% | $0.0940 | $0.0646–$0.12 | 5.5 | 20556 | 17980–23567 | 67% | 0 | 27% | 0 | 0 | 6 (5) |
| review | claude-sonnet-5-5@medium | on | 3/6 | 50%–50% | $0.0090 | $0.0088–$0.0096 | 2.0 | 11788 | 11740–11867 | 82% | 0 | 0% | 0 | 0 | 0 (0) |
| review | gpt-6.1-terra@medium | on | 5/6 | 50%–100% | $0.0100 | $0.0037–$0.0144 | 3.0 | 9205 | 8947–12375 | 59% | 0 | 0% | 0 | 0 | 6 (4) |
| review | gpt-6.2-astra@medium-bare | off | 6/6 | 100%–100% | $0.0204 | $0.0162–$0.0247 | 2.0 | 2727 | 2695–2760 | 19% | 0 | 0% | 0 | 0 | 0 (0) |
| review | opus-5-5@medium-replicate | on | 6/6 | 100%–100% | $0.0212 | $0.0206–$0.0235 | 2.0 | 11963 | 11881–12089 | 82% | 0 | 0% | 0 | 0 | 0 (0) |
| review | claude-opus-5-5@medium | on | 6/6 | 100%–100% | $0.0213 | $0.0203–$0.0241 | 2.0 | 11947 | 11869–12120 | 82% | 0 | 0% | 0 | 0 | 0 (0) |
| review | gpt-6.2-sol@medium | on | 6/6 | 100%–100% | $0.0222 | $0.0128–$0.0243 | 3.5 | 10845 | 9118–12506 | 46% | 0 | 0% | 0 | 0 | 6 (4) |
| review | claude-fable-5-2@medium-bare | off | 6/6 | 100%–100% | $0.0308 | $0.0286–$0.0334 | 2.0 | 5618 | 5602–5736 | 75% | 0 | 0% | 0 | 0 | 0 (0) |
| review | claude-fable-5-2@medium | on | 6/6 | 100%–100% | $0.0382 | $0.0342–$0.0393 | 2.0 | 11880 | 11756–11922 | 82% | 0 | 0% | 0 | 0 | 0 (0) |
| review | gpt-6.2-astra@medium | on | 6/6 | 100%–100% | $0.0732 | $0.0393–$0.11 | 3.0 | 9306 | 9045–12224 | 43% | 0 | 5% | 0 | 0 | 6 (3) |
| search | gpt-6.1-terra@medium | on | 6/6 | 100%–100% | $0.0064 | $0.0012–$0.0117 | 3.5 | 11099 | 5874–13212 | 47% | 0 | 16% | 0 | 0 | 0 (0) |
| search | claude-sonnet-5-5@medium | on | 6/6 | 100%–100% | $0.0113 | $0.0087–$0.0151 | 2.5 | 15372 | 11799–25341 | 85% | 1 | 0% | 0 | 0 | 0 (0) |
| search | gpt-6.2-sol@medium | on | 6/6 | 100%–100% | $0.0149 | $0.0116–$0.0164 | 3.0 | 9476 | 9151–9918 | 33% | 0 | 28% | 0 | 0 | 0 (0) |
| search | claude-opus-5-5@medium | on | 6/6 | 100%–100% | $0.0259 | $0.0226–$0.0317 | 3.0 | 18591 | 18222–19222 | 85% | 0 | 0% | 0 | 0 | 0 (0) |
| search | opus-5-5@medium-replicate | on | 6/6 | 100%–100% | $0.0277 | $0.0228–$0.0325 | 3.0 | 18853 | 18233–25149 | 87% | 3 | 0% | 0 | 0 | 0 (0) |
| search | gpt-6.2-astra@medium-bare | off | 6/6 | 100%–100% | $0.0345 | $0.0164–$0.0495 | 3.0 | 4805 | 2744–5258 | 23% | 0 | 19% | 0 | 0 | 0 (0) |
| search | claude-fable-5-2@medium-bare | off | 6/6 | 100%–100% | $0.0383 | $0.0353–$0.0515 | 3.0 | 9184 | 8996–13076 | 78% | 3 | 9% | 0 | 0 | 0 (0) |
| search | claude-fable-5-2@medium | on | 6/6 | 100%–100% | $0.0467 | $0.0428–$0.0588 | 3.0 | 18598 | 18259–25466 | 86% | 3 | 0% | 0 | 0 | 0 (0) |
| search | gpt-6.2-astra@medium | on | 6/6 | 100%–100% | $0.0571 | $0.0238–$0.0678 | 3.0 | 9792 | 5976–12541 | 45% | 1 | 11% | 0 | 0 | 0 (0) |
| small-fix | gpt-6.1-terra@medium | on | 6/6 | 100%–100% | $0.0088 | $0.0044–$0.0133 | 6.0 | 21163 | 21106–21954 | 68% | 6 | 17% | 0 | 0 | 0 (0) |
| small-fix | claude-sonnet-5-5@medium | on | 6/6 | 100%–100% | $0.0158 | $0.0146–$0.0177 | 5.0 | 32368 | 31665–33214 | 90% | 6 | 7% | 0 | 0 | 0 (0) |
| small-fix | gpt-6.2-sol@medium | on | 6/6 | 100%–100% | $0.0202 | $0.0128–$0.0218 | 6.0 | 20887 | 18337–22057 | 64% | 6 | 9% | 0 | 0 | 0 (0) |
| small-fix | opus-5-5@medium-replicate | on | 6/6 | 100%–100% | $0.0308 | $0.0285–$0.0327 | 4.0 | 25851 | 25506–26209 | 88% | 0 | 25% | 0 | 0 | 0 (0) |
| small-fix | claude-opus-5-5@medium | on | 6/6 | 100%–100% | $0.0318 | $0.0290–$0.0327 | 4.0 | 26096 | 25530–26237 | 88% | 0 | 29% | 0 | 0 | 0 (0) |
| small-fix | claude-fable-5-2@medium-bare | off | 6/6 | 100%–100% | $0.0499 | $0.0389–$0.0562 | 4.0 | 14339 | 13360–15933 | 81% | 0 | 29% | 0 | 0 | 0 (0) |
| small-fix | gpt-6.2-astra@medium-bare | off | 6/6 | 100%–100% | $0.0532 | $0.0331–$0.0714 | 5.0 | 9606 | 8688–10265 | 43% | 5 | 13% | 0 | 0 | 0 (0) |
| small-fix | claude-fable-5-2@medium | on | 6/6 | 100%–100% | $0.0543 | $0.0504–$0.0627 | 4.0 | 26445 | 26002–27044 | 87% | 0 | 8% | 0 | 0 | 0 (0) |
| small-fix | gpt-6.2-astra@medium | on | 6/6 | 100%–100% | $0.0689 | $0.0397–$0.0795 | 5.0 | 17802 | 17283–18370 | 63% | 6 | 10% | 0 | 0 | 0 (0) |

## Threshold per class (lowest median cost among arms whose worst repetition reaches 90%)

- multi-file: gpt-6.1-terra@medium at $0.0135/run
- review: opus-5-5@medium-replicate at $0.0212/run
- search: gpt-6.1-terra@medium at $0.0064/run
- small-fix: gpt-6.1-terra@medium at $0.0088/run

## Effort saturation (lowest effort with the best pass rate)

- multi-file · anthropic/claude-opus-5-5: medium (100%)
- review · anthropic/claude-opus-5-5: medium (100%)
- search · anthropic/claude-opus-5-5: medium (100%)
- small-fix · anthropic/claude-opus-5-5: medium (100%)

Differences smaller than the spread between replicate arms of the same model are noise.
